from flask import Flask,render_template,request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)
@app.route('/',methods=['GET'])
def welcome():
    return render_template('index.html',response='hello world')
   
@app.route('/login-form',methods=['POST'])
def login_form():
    name = request.form['name']
    phone = request.form['phone']
    # return [name,phone]
    return render_template('response.html',response=[name,phone])
 
 
@app.route('/login',methods=['GET'])
def login():
    return render_template('login.html')


@app.route('/about',methods=['GET'])
def about():
    return render_template('about.html')


@app.route('/portfolio',methods=['GET'])
def portfolio():
    return render_template('portfolio.html')


@app.route('/pricing',methods=['GET'])
def pricing():
    return render_template('pricing.html')


@app.route('/testimonials',methods=['GET'])
def testimonials():
    return render_template('testimonials.html')



@app.route('/services',methods=['GET'])
def services():
    return render_template('services.html')


@app.route('/contact',methods=['GET'])
def contact():
    return render_template('contact.html')


@app.route('/signin',methods=['GET'])
def signin():
    return render_template('signin.html')







if __name__ == '__main__':
    app.run(debug=True)

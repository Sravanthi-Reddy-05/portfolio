# app.py

from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///contacts.db'
db = SQLAlchemy(app)

class Contact(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(200), nullable=False)
    message = db.Column(db.Text, nullable=False)

@app.route('/',methods=['GET'])
def index():
    return render_template('index.html')
@app.route('/about',methods=['GET'])
def about():
    return render_template('about.html')
@app.route('/contact',methods=['GET'])
def contact():
    return render_template('contact.html')

from flask import flash

@app.route('/submit', methods=['POST'])
def submit():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        message = request.form['message']

        try:
            with app.app_context():
                new_contact = Contact(name=name, email=email,message=message)
                db.session.add(new_contact)
                db.session.commit()
                flash('Contact submitted successfully!', 'success')
        except Exception as e:
            app.logger.error(f"An error occurred while submitting contact: {str(e)}")
            flash('An error occurred while submitting contact. Please try again later.', 'error')
            return redirect(url_for('index'))

        return redirect(url_for('index'))


@app.route('/contacts')
def contacts():
    contacts = Contact.query.all()
    return render_template('contacts.html', contacts=contacts)

@app.route('/delete/<int:id>', methods=['POST'])
def delete_contact(id):
    contact = Contact.query.get_or_404(id)
    db.session.delete(contact)
    db.session.commit()
    return redirect(url_for('contacts'))

if __name__ == '__main__':
    app.secret_key='super secret key'
    app.config['SESSION_TYPE']='filesystem'


    with app.app_context():
        db.create_all()
    app.run(debug=True)

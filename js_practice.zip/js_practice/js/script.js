function text(){

    document.getElementById('new').innerHTML='hello';
}
    